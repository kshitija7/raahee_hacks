import 'package:flutter/material.dart';
import 'package:raheeapp/layouts/ForumDetails.dart';
import 'package:raheeapp/root_page.dart';
import 'Services/authentication.dart';
import 'Services/service_locator.dart';
import 'layouts/categoriesPage.dart';
import 'layouts/chatMode.dart';
import 'layouts/chat_feature/chatInitiate.dart';
import 'layouts/forums.dart';
import 'layouts/homePage.dart';
//import 'layouts/login_signup.dart';
import 'layouts/methodPsychologist.dart';
import 'layouts/professionalListPage.dart';
import 'layouts/random_game.dart';
import 'layouts/musicPage.dart';

void main() {
  setupLocator();  //required for call feature
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  static const primarySwatch = Colors.pink;
  // button color
  static const buttonColor = Colors.pinkAccent;
  // app name
  static const appName = 'Raahee';
  // boolean for showing home page if user unverified
  static const homePageUnverified = false;

  final params = {
    'appName': appName,
    'primarySwatch': primarySwatch,
    'buttonColor': buttonColor,
    'homePageUnverified': homePageUnverified,
  };
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Flutter login',
        home: new RootPage(params: params,auth: new Auth()),
        debugShowCheckedModeBanner: true,
        theme: new ThemeData(
          primarySwatch: params['primarySwatch'],
        ),
        routes: {
          '/home': (BuildContext context) => HomePage(),
         // '/login': (BuildContext context) => LoginSignUpPage(),
         // '/register': (BuildContext context) => RegisterPage(),
          '/forums' : (BuildContext context) => ForumPage(),
          '/music' : (BuildContext context) => MusicPage(),
          '/methodPsycho' : (BuildContext context) => PsychoSelectionPage(),
          '/game' : (BuildContext context) => GamePage(),
          '/forumDetail': (BuildContext context) => ForumDetails(),
          '/categoriesPage': (BuildContext context) => CategoriesPage(),
          '/professionalListPage' : (BuildContext context) => ProfessionalListPage(),
          '/chatMode' : (BuildContext context) => ChatMode(),
          '/chatInitiate' : (BuildContext context) => ChatInitiate(),
        }
    );
  }
}