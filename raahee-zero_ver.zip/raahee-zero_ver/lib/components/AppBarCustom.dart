import 'package:flutter/material.dart';
import 'package:raheeapp/components/appColorTheme.dart';
import 'package:wave/wave.dart';
import 'package:wave/config.dart';

class AppBarCustom extends PreferredSize {
  final Color bgColor;
  final double height;
  final String title;

  @override
  // TODO: implement preferredSize
  Size get preferredSize => Size(0,height);



  const AppBarCustom({
    this.bgColor =Colors.transparent,
    this.height = 90.0,
    this.title = ''
  });

  @override
  Widget build(BuildContext context) {
    return PreferredSize(
      preferredSize:preferredSize,
        child: Stack(
            children: <Widget>[
              RotatedBox(
                quarterTurns: 2,
                child: WaveWidget(
                  config: CustomConfig(
                    gradients: [
                      [AppColorsTheme().blueish, AppColorsTheme().blueish],
                      [AppColorsTheme().pinkShades[0],AppColorsTheme().pinkShades[0]],
                    ],
                    durations: [35000, 19440],
                    heightPercentages: [0.1, 0.25],
                    blur: MaskFilter.blur(BlurStyle.solid, 10),
                    gradientBegin: Alignment.bottomLeft,
                    gradientEnd: Alignment.topRight,
                  ),
                  waveAmplitude: 0,
                  backgroundColor: bgColor,
                  size: Size(
                    double.infinity,
                    double.infinity,
                  ),
                ),
              ),
              Column(
                children: <Widget>[
                  SizedBox(height:30),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      BackButton(

                        onPressed: (){
                          Navigator.pop(context);
                        },
                      ),
                      Text('$title', style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)
                    ],
                  ),
                ],
              ),
            ]));
  }
}
