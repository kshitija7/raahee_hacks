import 'package:flutter/material.dart';

class AppColorsTheme {

  List<Color> pinkShades = [Color(0xfff7adc4),Color(0xfff78bab),];
  List<Color> redShades = [Color(0xfff7adc4),Color(0xfff78bab),];
  Color textFadedColor = Color(0xBB000000);
  Color blueish = Color(0xFFbbbedd);
}