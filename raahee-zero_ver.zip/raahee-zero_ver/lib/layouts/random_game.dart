import 'package:flutter/material.dart';
import 'package:raheeapp/components/AppBarCustom.dart';

class GamePage extends StatefulWidget {
  @override
  _GamePageState createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarCustom(
        bgColor: Colors.transparent,
        title:'Put Game here'
      ),
    );
  }
}
