/*
* User can choose to talk with either a Professional(counselor, therapist etc.) or Raahee Buddy(representative from Raahee)
* This dart file is responsible for displaying these two options to the user
* Talking with a professional supports three options- voice call, chat and video call
* Talking with a Raahee buddy supports only one option- chat
* */
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../components/AppBarCustom.dart';

class PsychoSelectionPage extends StatefulWidget {
  @override
  _PsychoSelectionPageState createState() => _PsychoSelectionPageState();
}

class _PsychoSelectionPageState extends State<PsychoSelectionPage> {
  final double _cardWidth = 180.0;
  final double _cardHeight = 300.0;
  final double _imageWidth = 180.0;
  final double _imageHeight = 200.0;
  final double _cardFontSize = 19.0;
  final double _cardCaptionFontSize = 13.0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarCustom(
        title: "We're here for you",
      ),
        bottomNavigationBar: CurvedNavigationBar(
          color:Color(0xfff7adc4),
          buttonBackgroundColor: Colors.white,
          backgroundColor: Colors.white10,

          //  backgroundColor: ,

          items: <Widget>[
            Icon(Icons.verified_user,size:20,color:Colors.black),
            Icon(Icons.music_note,size:20,color:Colors.black),
            Icon(Icons.offline_pin,size:20,color:Colors.black),
            Icon(Icons.home,size:20,color:Colors.black),
          ],
          onTap: (index){
            //debugPrint('Current Index is $index');
          },
        ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Center(
              child: Text(
                "I want to talk with-",
                style: GoogleFonts.sriracha(
                  fontSize: 22.0,
                ),
              )
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Card(
                  elevation: 10,
                  color: Color.fromARGB(255, 233, 227, 244),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0)
                  ),
                  child: InkWell(
                    child: Container(
                        width: _cardWidth,
                        height: _cardHeight,
                        child: Column(
                          children: <Widget>[
                            Image.asset(
                              'assets/images/clip-welcome.png',
                              height: _imageHeight,
                              width: _imageWidth,
                              fit: BoxFit.cover,
                            ),
                            Text(
                              "Professional",
                              style: GoogleFonts.sriracha(
                                fontSize: _cardFontSize,
                              ),
                            ),
                            Text(
                              "Therapists and Counselors",
                                textAlign: TextAlign.center,
                                style: GoogleFonts.openSans(
                                    fontSize: _cardCaptionFontSize
                                ),
                            )
                          ],
                        )
                    ),
                    onTap: () => {
                      Navigator.pushNamed(context, '/categoriesPage')
                    },
                  )
                  ),
                Card(
                  elevation: 10,
                  color: Color.fromARGB(255, 233, 227, 244),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0)
                  ),
                  child: InkWell(
                    child: Container(
                      height: _cardHeight,
                      width: _cardWidth,
                      child: Column(
                        children: <Widget>[
                          Image.asset(
                            'assets/images/clip-done.png',
                            width: _imageWidth,
                            height: _imageHeight,
                            fit: BoxFit.cover,
                          ),
                          Text(
                            "Raahee Buddy",
                            style: GoogleFonts.sriracha(
                              fontSize: _cardFontSize,
                            ),
                          ),
                          Text(
                            "representatives from Raahee",
                            textAlign: TextAlign.center,
                            style: GoogleFonts.openSans(
                              fontSize: _cardCaptionFontSize
                            ),
                          )
                        ],
                      ),
                    ),
                      onTap: () => {

                      },
                  )
                )
              ],
            )
          ],
        ),
      )
    );
  }
}

