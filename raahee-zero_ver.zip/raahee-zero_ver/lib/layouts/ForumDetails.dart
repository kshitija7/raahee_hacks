import 'package:flutter/material.dart';
import 'package:raheeapp/components/AppBarCustom.dart';
import 'package:raheeapp/utils/ForumElement.dart';

class ForumDetails extends StatefulWidget {
  @override
  _ForumDetailsState createState() => _ForumDetailsState();
}

class _ForumDetailsState extends State<ForumDetails> {
  @override
  Widget build(BuildContext context) {
    final Map _forumArgument =
    ModalRoute.of(context).settings.arguments as Map;

     Map<String,List<ForumElement>> _forumData = _forumArgument.values.first;
     _forumData.forEach((k,v){
       print(k);
       v.forEach((el){
         print(el.description);
       });
     });


    return Scaffold(
        appBar: AppBarCustom(
            bgColor: Colors.transparent,
            title: _forumArgument.keys.first
        ),
        body: _forumArgument.values.first.length == 0 ? Center(child:Text("No Data")) :
          Text("some")
    );
  }


}
