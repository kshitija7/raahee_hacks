/*
* This Dart file is responsible for displaying a list of therapists and counselors for the user to choose from
* */
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:raheeapp/components/AppBarCustom.dart';

class Professional{
   String _name;
   String _designation;
   int _experienceInYears;

   Professional(String name, String designation, int experienceInYears){
     this._name = name;
     this._designation = designation;
     this._experienceInYears = experienceInYears;
   }

   void setName(String pName)
   {
     this._name = pName;
   }
   void setDesignation(String pDesignation)
   {
     this._designation = pDesignation;
   }
   void setExperienceInYears(int pExperienceInYears)
   {
     this._experienceInYears = pExperienceInYears;
   }

   String getName()
   {
     return this._name;
   }
   String getDesignation()
   {
     return this._designation;
   }
   int getExperienceInYears()
   {
     return this._experienceInYears;
   }

}
class ProfessionalListPage extends StatefulWidget {
  @override
  _ProfessionalListPageState createState() => _ProfessionalListPageState();
}

class _ProfessionalListPageState extends State<ProfessionalListPage> {
   List<Professional> professionals = List<Professional>();
   final double _imageWidth = 100.0;
   final double _imageHeight = 100.0;
  //code for adding some psychologists or counselors for sample
   void populateList()
   {
     professionals.add(new Professional("Dr. Meera Singh", "Psychologist", 10));
     professionals.add(new Professional("Dr. Aman Sharma", "Child Psychologist", 8));
     professionals.add(new Professional("Dr. Sumit Jain", "Psychotherapist", 12));
     professionals.add(new Professional("Dr. Kumud Saini", "Career Counseling Expert", 6));
     professionals.add(new Professional("Dr. Pranav Mittal", "Psychotherapist", 10));
   }
   //returns information container for each ListView item on page
   Widget getInformationContainer(Professional info)
   {
     return Card(
       color: Color.fromARGB(255, 233, 227, 244),
       child: Row(
         children: <Widget>[
           InkWell(
                onTap: () => {
                  Navigator.pushNamed(context, '/chatMode')
                },
               child: Row(
                 children: <Widget>[
                   Container(
                     width: _imageWidth,
                     height: _imageHeight,
                     child: Icon(
                       Icons.person,
                       size: 100.0,
                     ),
                   ),
                   Column(
                     children: <Widget>[
                       Text(info.getName(),
                         textAlign: TextAlign.left,
                         style: GoogleFonts.muli(
                         fontSize: 18.0,
                       ),),
                       Text(info.getDesignation(),
                         textAlign: TextAlign.left,
                         style: GoogleFonts.muli(
                         fontSize: 14.0,
                       ),),
                       Text("Experience: "+info.getExperienceInYears().toString()+" yrs",
                         textAlign: TextAlign.left,
                         style: GoogleFonts.muli(
                           fontSize: 12.0
                       ),)
                     ],
                   ),
                 ],
               )
           ),
         ],
       )
     );
   }
  @override
  Widget build(BuildContext context) {
    if(professionals.isEmpty)
      {
        populateList();
      } else
        {
          professionals.clear();
          populateList();
        }
    return Scaffold(
      appBar: AppBarCustom(
        title: "Choose a professional",
      ),
      bottomNavigationBar: CurvedNavigationBar(
        color:Color(0xfff7adc4),
        buttonBackgroundColor: Colors.white,
        backgroundColor: Colors.white10,

        //  backgroundColor: ,

        items: <Widget>[
          Icon(Icons.verified_user,size:20,color:Colors.black),
          Icon(Icons.music_note,size:20,color:Colors.black),
          Icon(Icons.offline_pin,size:20,color:Colors.black),
          Icon(Icons.home,size:20,color:Colors.black),
        ],
        onTap: (index){
          //debugPrint('Current Index is $index');
        },
      ),
      body: SafeArea(
        child: ListView.builder(
            itemCount: professionals.length,
            itemBuilder: (BuildContext context, int index) {
              return getInformationContainer(professionals[index]);
            }
        ),
      ),
    );
  }
}
