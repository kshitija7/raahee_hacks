//import 'dart:math';

import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:raheeapp/components/AppBarCustom.dart';
import 'package:raheeapp/components/appColorTheme.dart';

class MusicPage extends StatefulWidget {
  @override
  _MusicPageState createState() => _MusicPageState();
}


class _MusicPageState extends State<MusicPage> {

  int filesLength = 0;
  List<ButtonInfo> _node;
  int _nowPlaying=-1, _previousPlaying=-2;
  final AssetsAudioPlayer _assetsAudioPlayer = AssetsAudioPlayer();
  double _value = 0;
  @override
  void initState() {

    Firestore.instance.collection('musicFiles')
        .document('musicFiles').get().then((doc){
      _node = ButtonInfo(null,null,null,null)
                                          .getFromList(doc.data['node']);
      _assetsAudioPlayer.playlistFinished.listen((data) {
        print("finished : $data");
      });
      _assetsAudioPlayer.playlistAudioFinished.listen((data) {
        print("playlistAudioFinished : $data");
      });
      _assetsAudioPlayer.current.listen((data) {
        print("current : $data");
      });
      filesLength = _node.length;
      setState(() {

      });
    });
    super.initState();
  }

  @override
  void dispose() {
    _assetsAudioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBarCustom(
          bgColor: Colors.transparent,
          title: 'Relax',
        ),

        body:Column(
            children: <Widget>[
              SizedBox(height:75),
              Container(
                  height:200,
                  child:ListView(
                    scrollDirection: Axis.horizontal,
                    children: List.generate(filesLength, listGenerator),
                  )),
              StreamBuilder(
                  stream: _assetsAudioPlayer.current,
                  builder: (BuildContext context, AsyncSnapshot<Playing> snapshot) {
                    Duration totalDuration = Duration();
                    if (snapshot.hasData) {
                      totalDuration = snapshot.data.audio.duration;
                    }
                    return StreamBuilder(
                        stream: _assetsAudioPlayer.currentPosition,
                        initialData: const Duration(),
                        builder: (BuildContext context, AsyncSnapshot<Duration> snapshotInner) {
                          Duration duration = Duration();
                          if (snapshot.hasData) {
                            duration = snapshotInner.data;
                          }
                          if (duration.inSeconds !=null &&
                              duration.inMilliseconds > 0) {
                            _value = duration.inSeconds/totalDuration.inSeconds;
                            print(duration.inSeconds);
                            print(_value);
                          }

                          return   Container(
                              child: SliderTheme(
                                data: SliderTheme.of(context).copyWith(
                                  activeTrackColor: AppColorsTheme().pinkShades[1],
                                  inactiveTrackColor: Colors.red[100],
                                  trackShape: RectangularSliderTrackShape(),
                                  trackHeight: 4.0,
                                  thumbColor: Colors.redAccent,
                                  thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12.0),
                                  overlayColor: Colors.red.withAlpha(32),
                                  overlayShape: RoundSliderOverlayShape(overlayRadius: 28.0),
                                ),
                                child: Slider(
                                  value: _value,
                                  onChanged: (value) {
                                  },
                                ),
                              )
                          );
                        }
                    );
                  }
              ),
              Padding(
                  padding: EdgeInsets.fromLTRB(75, 0, 100, 0),
              child:Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  FlatButton(
                      onPressed: () {  },
                      child: Row(
                        children: <Widget>[
                          Icon(Icons.settings_input_antenna),
                          SizedBox(width:10),
                          Text('Podcasts',
                              style:TextStyle(
                                  fontSize: 25,
                              )),
                        ],
                      )
                  ),
                  Divider(color: Colors.black),
                  FlatButton(
                      onPressed: () {  },
                      child: Row(
                        children: <Widget>[
                          Icon(Icons.accessibility_new),
                          SizedBox(width:10),
                          Text('Exercises',
                              style:TextStyle(
                                fontSize: 25,
                              )),
                        ],
                      )
                  ),
                ],
              )
              )

            ]
        )

    );
  }

  Widget listGenerator(int i) {
    return(
        Container(
            width: 150.0,
            padding: EdgeInsets.all(5),
            child:RaisedButton(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(20))
              ),
              color: _node[i].pinkShade,
              child:Column(
                children: <Widget>[
                  SizedBox(height:30),
                  Text(_node[i].title, style: TextStyle(
                      fontSize:20,
                      color:Color(0x99000000)
                  )),
                  SizedBox(height:30),
                  Icon(_node[i].icon,
                      size:30),
                  StreamBuilder(
                    stream: _assetsAudioPlayer.isPlaying,
                    initialData: false,
                    builder: (BuildContext context, AsyncSnapshot<bool> snapshot) {
                      bool playing = false;
                      if(snapshot.data && _previousPlaying == i){
                        playing = true;
                      }
                      return IconButton(
                        onPressed: () {
                          if(_previousPlaying == i)
                            _assetsAudioPlayer.playOrPause();
                          else
                            _assetsAudioPlayer.open(Audio(_node[i].musicPath));
                          _previousPlaying = i;
                        },
                        icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                      );
                    },
                  ),
                ],
              ),
              onPressed: (){
                if(_previousPlaying == i)
                _assetsAudioPlayer.playOrPause();
                else
                _assetsAudioPlayer.open(Audio(_node[i].musicPath));
                _previousPlaying = i;
              },
            )
        )

    );
  }

}

class ButtonInfo {
  final String title;
  final IconData icon;
  final String musicPath;
  final Color pinkShade;
  List<ButtonInfo> getFromList(List<dynamic> node){

    List<ButtonInfo> toReturn = [];
    int colorIterator = 0;
    node.forEach((element){
      colorIterator++;
      var index = colorIterator%AppColorsTheme().pinkShades.length;    //3 pinks in my Color file
      Color pinkShade = AppColorsTheme().pinkShades[index];
      IconData icon = IconData(int.parse(element['icon']),
                                  fontFamily: 'MaterialIcons');
      ButtonInfo buttonInfoElement = new ButtonInfo(element['title'],
                                                    icon,
                                                    element['musicPath'],
                                                    pinkShade) ;
      toReturn.add(buttonInfoElement);
    });
    return toReturn;
  }
  ButtonInfo(this.title,this.icon, this.musicPath, this.pinkShade);
}
