/*
* this dart file is responsible for building a message widget
* */
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

const String _name = "Raahee User";

class ChatMessage extends StatelessWidget {

  final String message;

  ChatMessage({this.message});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(right: 16.0),
            child: CircleAvatar(
              child: Text(_name[0]),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(_name, style: GoogleFonts.openSans(
                fontSize: 15.0,
                color: Colors.deepPurple,
                fontWeight: FontWeight.bold
              ),),
              Container(
                margin: const EdgeInsets.only(top: 5.0),
                child: Text(message, style: GoogleFonts.openSans(
                  fontSize: 18.0
                ),),
              )
            ],
          )
        ],
      ),
    );
  }
}
