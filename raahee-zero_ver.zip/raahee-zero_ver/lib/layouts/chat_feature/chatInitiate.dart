/*
* this dart file is responsible for Chat Screen
* */
import 'package:flutter/material.dart';
import 'package:raheeapp/components/AppBarCustom.dart';

import 'chatMessage.dart';


class ChatInitiate extends StatefulWidget {
  @override
  _ChatInitiateState createState() => _ChatInitiateState();
}

class _ChatInitiateState extends State<ChatInitiate> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarCustom(
        title: "Let's Chat",
      ),
      body: SafeArea(child: ChatScreen())
    );
  }
}

class ChatScreen extends StatefulWidget {
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController  _textController = new TextEditingController();
  final List<ChatMessage> _messagesList = <ChatMessage> [];

  void _onSend(String message){
    _textController.clear();
    ChatMessage chatMessage = new ChatMessage(
      message: message,
    );
    setState(() {
      _messagesList.insert(0, chatMessage);
    });
  }

  Widget _textComposerWidget(){
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Row(
        children: <Widget>[
          Flexible(
            child: TextField(
              decoration: InputDecoration.collapsed(hintText: "Send a message"),
              controller: _textController,
              onSubmitted: _onSend,
            ),
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 4.0),
            child: IconTheme(
              data: IconThemeData(
                color: Colors.deepPurple,
              ),
              child: IconButton(
                  icon: Icon(Icons.send),
                  onPressed: () => _onSend(_textController.text)
              ),
            ),
          )
        ],
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Flexible(
          child: ListView.builder(
            padding: EdgeInsets.all(8.0),
            reverse: true,
            itemBuilder: (context, index) => _messagesList[index],
            itemCount: _messagesList.length,
          ),
        ),
        Divider(height: 1.0,),
        Container(
          decoration: new BoxDecoration(
              color: Theme.of(context).cardColor
          ),
          child: _textComposerWidget(),
        )
      ],
    );
  }
}
