import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:raheeapp/components/appColorTheme.dart';
import 'package:raheeapp/components/AppBarCustom.dart';
import 'package:raheeapp/utils/ForumElement.dart';
class ForumPage extends StatefulWidget {
  ForumPage({Key key}) : super(key: key);

  @override
  _ForumPageState createState() => new _ForumPageState();
}

class _ForumPageState extends State<ForumPage> {
  int filesLength = 0;
  List<String> _titles = [];
  Map<String,Map<String,List<ForumElement>>> _node = new Map();

  @override
  void initState() {
    print('init');
    Firestore.instance.collection('forums').getDocuments().then((snap) {
      snap.documents.forEach((doc) {
        _titles.add(doc.documentID);
        _node[doc.documentID] =new Map();
        doc.data.forEach((key,val){
          _node[doc.documentID][key] =[];
          print(key);
          val.forEach((k,v){
            _node[doc.documentID][key].add(ForumElement(doc.documentID,v));
          });
        });
      });
      print(_node['Covid19 Pandemic'].length);
      setState(() {
      });
    });

    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: AppBarCustom(
          bgColor: Colors.transparent,
          title: 'Forums',
        ),
        body: new Container(
            child: new ListView(
                children: List.generate(_titles.length, (index) {
                  return (
                      Row(
                          children: <Widget>[
                            Container(
                              padding:EdgeInsets.fromLTRB(0,5,10,5),
                              height:MediaQuery.of(context).size.height*0.15,
                              width:MediaQuery.of(context).size.width*0.65,
                              child:RaisedButton(
                                child: Text(_titles[index], style:
                                TextStyle(fontSize: 20)),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(20),
                                      bottomRight: Radius.circular(20))
                                ),
                                disabledColor: AppColorsTheme().pinkShades[0], onPressed: () {  },
                              )
                            ),
                            Container(
                                padding:EdgeInsets.fromLTRB(0,5,10,5),
                                height:MediaQuery.of(context).size.height*0.15,
                                width:MediaQuery.of(context).size.width*0.3,
                                child:RaisedButton(
                                  child:Text('Join'),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(Radius.circular(20))
                                  ),
                                  color:AppColorsTheme().blueish,
                                  onPressed: (){
                                    Navigator.pushNamed(
                                        context,
                                        '/forumDetail',
                                        arguments: {_titles[index] :
                                                    _node[_titles[index]]}
                                    );
                                  },
                                )
                            ),
                          ]
                      )
                  );
                }))));
  }
}
