/*
*This Dart file is responsible for displaying chat options(voice call, video call or chat) to the user
* */
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:raheeapp/components/AppBarCustom.dart';
import 'package:raheeapp/Services/calls_and_messages_service.dart';
import 'package:raheeapp/Services/service_locator.dart';

class ChatMode extends StatefulWidget {
  @override
  _ChatModeState createState() => _ChatModeState();
}

class _ChatModeState extends State<ChatMode> {
  final CallsAndMessagesService _service = locator<CallsAndMessagesService>();
  final String number = "123456789";
  final double _iconWidth = 100.0;
  final double _iconHeight = 100.0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarCustom(
        title: "Choose the mode",
      ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Card(
              color: Color.fromARGB(255, 233, 227, 244),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.0),
              ),
              child: InkWell(
                onTap: () => {
                  Navigator.pushNamed(context, '/chatInitiate')
                },
                child: Row(
                  children: <Widget>[
                    Container(
                      width: _iconWidth,
                      height: _iconHeight,
                      child: Icon(
                        Icons.chat,
                        size: 100.0,
                      ),
                    ),
                    Text(
                      "Chat",
                        textAlign: TextAlign.center,
                      style: GoogleFonts.muli(
                        fontSize: 22.0
                      )
                    )
                  ],
                ),
              ),
            ),
            Card(
              color: Color.fromARGB(255, 233, 227, 244),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.0),
              ),
              child: InkWell(
                onTap: () => {
                  _service.call(number)
                },
                child: Row(
                  children: <Widget>[
                    Container(
                      width: _iconWidth,
                      height: _iconHeight,
                      child: Icon(
                        Icons.call,
                        size: 100.0,
                      ),
                    ),
                    Text(
                        "Voice Call",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.muli(
                            fontSize: 22.0
                        )
                    )
                  ],
                ),
              ),
            ),
            Card(
              color: Color.fromARGB(255, 233, 227, 244),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.0),
              ),
              child: InkWell(
                onTap: () => {

                },
                child: Row(
                  children: <Widget>[
                    Container(
                      width: _iconWidth,
                      height: _iconHeight,
                      child: Icon(
                        Icons.video_call,
                        size: 100.0,
                      ),
                    ),
                    Text(
                        "Video Call",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.muli(
                            fontSize: 22.0
                        )
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      )
    );
  }
}
