import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:raheeapp/Services/authentication.dart';
import 'package:raheeapp/components/AppBarCustom.dart';
import 'dart:math';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raheeapp/components/appColorTheme.dart';

class HomePage extends StatefulWidget {

  final String name;
  final Map params;
  final BaseAuth auth;
  final VoidCallback onSignedOut;
  final String userId;
  HomePage({Key key, this.params, this.auth, this.userId, this.onSignedOut, this.name})
      : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int value = 0;
  final _random = new Random();
  String quote = "";
  final String bottomImagePath='assets/bottom.svg';

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  bool _isEmailVerified = false;

  @override
  void initState() {
    _checkEmailVerification().whenComplete(() {
      if (!_isEmailVerified && !widget.params['homePageUnverified']) {
        // sign out if email not verified and the parameter is set to not show to unverified user
        _signOut();
      }
    });

    Firestore.instance.collection('quotes').document('quotes').get().then((doc){
      Map<String,dynamic> quotes = doc.data;
      var index = _random.nextInt(quotes['motivational'].length);
      setState(() {
        quote = quotes['motivational'][index];
      });

      print(quote);
    }
    );
    super.initState();

  }

  Future<void> _checkEmailVerification() async {
    _isEmailVerified = await widget.auth.isEmailVerified();
    if (!_isEmailVerified) {
      _showVerifyEmailDialog();
    }
  }

  void _resendVerifyEmail() {
    widget.auth.sendEmailVerification();
    _showVerifyEmailSentDialog();
  }

  void _showVerifyEmailDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: new Text("Verify your account"),
          content: new Text("Please verify account in the link sent to email"),
          actions: <Widget>[
            new FlatButton(
              child: new Text("Resend verification email"),
              onPressed: () {
                Navigator.of(context).pop();
                _resendVerifyEmail();
              },
            ),
            new FlatButton(
              child: new Text("Dismiss"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _showVerifyEmailSentDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: new Text("Verify your account"),
          content:
          new Text("Link to verify account has been sent to your email"),
          actions: <Widget>[
            new FlatButton(
              child: new Text("Dismiss"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  _signOut() async {
    try {
      await widget.auth.signOut();
      widget.onSignedOut();
    } catch (e) {
      print(e);
    }
  }

  @override
  void dispose() {
    super.dispose();
  }


  // Widget _mainScreen() {
  //   return Center(child: Text("Welcome.",
  //     textAlign: TextAlign.center,
  //     style: TextStyle(fontSize: 30.0),));
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarCustom(
        //bgColor: Colors.transparent,
        title: 'Hi ${widget.name}',
      ),
      body: Container(
          padding: EdgeInsets.fromLTRB(20,20,20,0),
          child: Column(
            children: <Widget>[
              Text(quote, style:
                TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 24,
                  color: AppColorsTheme().textFadedColor)
              ),
              SizedBox(height:20),
              Row(
              children: <Widget>[
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: AspectRatio(
                    aspectRatio: 2,
                    child: Container(
                      width: double.infinity,
                      child:RaisedButton(
                        color:AppColorsTheme().pinkShades[0],
                        child:Text('Talk to Psychologist'),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                                topLeft:Radius.circular(20))),
                        onPressed: (){
                          Navigator.pushNamed(context, '/methodPsycho');
                        },
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Padding(padding: const EdgeInsets.all(2.0),
                  child: AspectRatio(
                    aspectRatio: 2,
                    child: Container(
                      width: double.infinity,
                      child:RaisedButton(
                        color:AppColorsTheme().pinkShades[0],
                        child:Text('Forums'),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                                topRight:Radius.circular(20))),
                        onPressed: (){
                          Navigator.pushNamed(context, '/forums');
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: AspectRatio(
                        aspectRatio: 2,
                        child: Container(
                          width: double.infinity,
                          child:RaisedButton(
                            color:AppColorsTheme().pinkShades[0],
                            child:Text('Play a Game'),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.only(
                                    bottomLeft:Radius.circular(20))),
                            onPressed: (){
                              Navigator.pushNamed(context, '/game');
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(padding: const EdgeInsets.all(2.0),
                      child: AspectRatio(
                        aspectRatio: 2,
                        child: Container(
                          width: double.infinity,
                          child:RaisedButton(
                            color:AppColorsTheme().pinkShades[0],
                            child:Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[

                                Text('Relax'),
                                Icon(Icons.music_note),

                              ],
                            ),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.only(
                                    bottomRight:Radius.circular(20))),
                            onPressed: (){
                              Navigator.pushNamed(context, '/music');
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height:20),
              Expanded(
                child: Text("How are you feeling today?"),
              ),
              Expanded(
                child:SvgPicture.asset(
                    bottomImagePath,
                    semanticsLabel: 'Bottom Image'
                )
              )
            ],
          ),
      ),
      floatingActionButton: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              FloatingActionButton(
                heroTag: "btn1",
                child: Icon(Icons.chat),
                backgroundColor: AppColorsTheme().pinkShades[0],
                onPressed: (){
            }
            ),
              FloatingActionButton(
                heroTag: "btn2",
                child: Text('Sign Out'),
                backgroundColor: AppColorsTheme().pinkShades[0],
                onPressed: (){
                  _signOut();
                },
              )
            ],
      )
    );
  }
}