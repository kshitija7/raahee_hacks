/*
* If user chooses to talk to a Professional(counselor, therapist etc.), different categories will be displayed to the users
* Selection of a particular category will help to suggest specialized professionals in that category to the user
* This dart file is responsible for displaying these categories(stress, anxiety, depression etc.)
* */
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:raheeapp/components/AppBarCustom.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

class CategoriesPage extends StatefulWidget {
  @override
  _CategoriesPageState createState() => _CategoriesPageState();
}

class _CategoriesPageState extends State<CategoriesPage> {
  List<String> categoriesList = [
    "Stress",
    "Anxiety",
    "Grief",
    "Depression",
    "Bullied",
    "Fear",
    "Inferiority Complex",
    "Career Issues",
    "OCD",
    "Marriage Counseling",
    "Peer Pressure",
    "Stress Eating",
    "LGBTQ+",
    "Paranoia",
  ];
  Widget getTileContent(String tileName)
  {
    return Card(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0)
        ),
        color: Color.fromARGB(255, 233, 227, 244),
        child: InkWell(
          onTap: () => {
            Navigator.pushNamed(context, '/professionalListPage')
          },
          child: Text(
              tileName,
              textAlign: TextAlign.center,
              style: GoogleFonts.sriracha(
                fontSize: 18.0
              ),
            ),
        ),
      );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarCustom(
        title: "Choose a category",
      ),
      bottomNavigationBar: CurvedNavigationBar(
        color:Color(0xfff7adc4),
        buttonBackgroundColor: Colors.white,
        backgroundColor: Colors.white10,

        //  backgroundColor: ,

        items: <Widget>[
          Icon(Icons.verified_user,size:20,color:Colors.black),
          Icon(Icons.music_note,size:20,color:Colors.black),
          Icon(Icons.offline_pin,size:20,color:Colors.black),
          Icon(Icons.home,size:20,color:Colors.black),
        ],
        onTap: (index){
          //debugPrint('Current Index is $index');
        },
      ),
      body: SafeArea(
        child: Container(
          child: StaggeredGridView.count(
            crossAxisCount: 3,
            mainAxisSpacing: 2,
            crossAxisSpacing: 2,
            staggeredTiles: [
              StaggeredTile.count(2, 1),
              StaggeredTile.count(1, 1),
              StaggeredTile.count(1, 1),
              StaggeredTile.count(2, 1),
              StaggeredTile.count(1, 1),
              StaggeredTile.count(1, 1),
              StaggeredTile.count(2, 1),
              StaggeredTile.count(1, 2),
              StaggeredTile.count(1, 1),
              StaggeredTile.count(2, 1),
              StaggeredTile.count(2, 1),
              StaggeredTile.count(1, 2),
              StaggeredTile.count(1, 1),
              StaggeredTile.count(1, 1),
            ],
            children: List.generate(categoriesList.length, (index) => getTileContent(categoriesList[index])),
          ),
        ),
      ),
    );
  }
}
