

class ForumElement {
  final String title;
  final String description;

  ForumElement getFromMap(Map<dynamic,String> node){
    return ForumElement(null,null);
  }

  ForumElement(this.title, this.description);
}
